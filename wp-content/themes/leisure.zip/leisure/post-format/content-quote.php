<article id="post-<?php the_ID(); ?>" <?php post_class('entry animated'); ?>>

	<?php the_content(); ?>

</article>