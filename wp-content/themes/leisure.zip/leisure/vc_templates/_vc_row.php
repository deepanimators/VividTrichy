<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * Shortcode attributes
 * @var $atts
 * @var $el_class
 * @var $full_width
 * @var $full_height
 * @var $content_placement
 * @var $parallax
 * @var $parallax_image
 * @var $css
 * @var $el_id
 * @var $video_bg
 * @var $video_bg_url
 * @var $video_bg_parallax
 * @var $content - shortcode content
 * Shortcode class
 * @var $this WPBakeryShortCode_VC_Row
 */
$el_class = $full_height = $full_width = $content_placement = $parallax = $parallax_image = $css = $el_id = $video_bg = $video_bg_url = $video_bg_parallax = '';
$output = $after_output = '';
$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
extract( $atts );

wp_enqueue_script( 'wpb_composer_front_js' );

$el_class = $this->getExtraClass( $el_class );

$css_classes = array(
	'vc_row',
	'wpb_row', //deprecated
	'vc_row-fluid',
	$el_class,
	vc_shortcode_custom_css_class( $css ),
);
$wrapper_attributes = array();
// build attributes for wrapper
if ( ! empty( $el_id ) ) {
	$wrapper_attributes[] = 'id="' . esc_attr( $el_id ) . '"';
}
if ( ! empty( $full_width ) ) {
	$wrapper_attributes[] = 'data-vc-full-width="true"';
	$wrapper_attributes[] = 'data-vc-full-width-init="false"';
	if ( 'stretch_row_content' === $full_width ) {
		$wrapper_attributes[] = 'data-vc-stretch-content="true"';
	} elseif ( 'stretch_row_content_no_spaces' === $full_width ) {
		$wrapper_attributes[] = 'data-vc-stretch-content="true"';
		$css_classes[] = 'vc_row-no-padding';
	}
	$after_output .= '<div class="vc_row-full-width"></div>';
}

if ( ! empty( $full_height ) ) {
	$css_classes[] = ' vc_row-o-full-height';
	if ( ! empty( $content_placement ) ) {
		$css_classes[] = ' vc_row-o-content-' . $content_placement;
	}
}

$has_video_bg = ( ! empty( $video_bg ) && ! empty( $video_bg_url ) && vc_extract_youtube_id( $video_bg_url ) );

if ( $has_video_bg ) {
	$parallax = $video_bg_parallax;
	$parallax_image = $video_bg_url;
	$css_classes[] = ' vc_video-bg-container';
	wp_enqueue_script( 'vc_youtube_iframe_api_js' );
}

if ( ! empty( $parallax ) ) {
	wp_enqueue_script( 'vc_jquery_skrollr_js' );
	$wrapper_attributes[] = 'data-vc-parallax="1.5"'; // parallax speed
	$css_classes[] = 'vc_general vc_parallax vc_parallax-' . $parallax;
	if ( false !== strpos( $parallax, 'fade' ) ) {
		$css_classes[] = 'js-vc_parallax-o-fade';
		$wrapper_attributes[] = 'data-vc-parallax-o-fade="on"';
	} elseif ( false !== strpos( $parallax, 'fixed' ) ) {
		$css_classes[] = 'js-vc_parallax-o-fixed';
	}
}

if ( ! empty( $parallax_image ) ) {
	if ( $has_video_bg ) {
		$parallax_image_src = $parallax_image;
	} else {
		$parallax_image_id = preg_replace( '/[^\d]/', '', $parallax_image );
		$parallax_image_src = wp_get_attachment_image_src( $parallax_image_id, 'full' );
		if ( ! empty( $parallax_image_src[0] ) ) {
			$parallax_image_src = $parallax_image_src[0];
		}
	}
	$wrapper_attributes[] = 'data-vc-parallax-image="' . esc_attr( $parallax_image_src ) . '"';
}
if ( ! $parallax && $has_video_bg ) {
	$wrapper_attributes[] = 'data-vc-video-bg="' . esc_attr( $video_bg_url ) . '"';
}





/**  Curly Theme Extension  */

$parallax_layers_html 	= '';
$video_bg 				= apply_filters( 'curly_video_bg', $video_cover, $video, $video_mp4, $video_ogg, $video_webm );
$wrapper_attributes[] 	= apply_filters( 'curly_vc_css', $min_height, $position );
$wrapper_attributes 	= is_array( $video_bg ) ? array_merge( $wrapper_attributes, $video_bg ) : $wrapper_attributes;  


if( $parallax_layers === 'yes' ){
	$parallax_layers_html .= apply_filters( 'curly_parallax_layer', $layer_1, $layer_1_vertical, $layer_1_horizontal, $layer_1_ratio, $layer_1_width, $layer_1_height, $layer_1_z, $style_images );
	$css_classes[] = 'parallax-container';
	$parallax_layers_html .= apply_filters( 'curly_parallax_layer', $layer_2, $layer_2_vertical, $layer_2_horizontal, $layer_2_ratio, $layer_2_width, $layer_2_height, $layer_2_z, $style_images );
	$parallax_layers_html .= apply_filters( 'curly_parallax_layer', $layer_3, $layer_3_vertical, $layer_3_horizontal, $layer_3_ratio, $layer_3_width, $layer_3_height, $layer_3_z, $style_images );
}

if( $parallax_offset !== '' ){
	$wrapper_attributes[] = "data-stellar-vertical-offset='$parallax_offset'";
	$wrapper_attributes[] = "data-stellar-offset-parent='true'";
}

/** [Curly Extension Here]  */








$css_class = preg_replace( '/\s+/', ' ', apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, implode( ' ', array_filter( $css_classes ) ), $this->settings['base'], $atts ) );
$wrapper_attributes[] = 'class="' . esc_attr( trim( $css_class ) ) . '"';

$output .= '<div ' . implode( ' ', $wrapper_attributes ) . '>';
$output .= ( filter_var( $grid, FILTER_VALIDATE_BOOLEAN ) === true ) ? '<div class="main-wrapper">' : '';
$output .= wpb_js_remove_wpautop( $content ); 
$output .= ( filter_var( $grid, FILTER_VALIDATE_BOOLEAN ) === true ) ? '</div>' : '';
$output .= $parallax_layers_html;
$output .= '</div>';
$output .= $after_output;

echo $output;
