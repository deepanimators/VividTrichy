<?php
require_once( trailingslashit( get_template_directory() ) . 'defaults/ips/page.title.php' );
require_once( trailingslashit( get_template_directory() ) . 'defaults/ips/header.php' );
require_once( trailingslashit( get_template_directory() ) . 'defaults/ips/background.php' );
require_once( trailingslashit( get_template_directory() ) . 'defaults/ips/coming.soon.php' );
require_once( trailingslashit( get_template_directory() ) . 'defaults/ips/contact.php' );
