Please read the documentation provided in the downloaded package 
or read it online here: http://docs.curlythemes.com/leisurewp/