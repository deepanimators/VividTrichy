<?php dynamic_sidebar( CurlyThemes::get_sidebar( 'sidebar_blog' ) ); ?>
