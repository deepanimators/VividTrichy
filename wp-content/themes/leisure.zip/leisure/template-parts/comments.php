<?php if ( comments_open() ) : ?>
<div class="row">
	<div class="col-sm-12">
		<?php comments_template();  ?>
	</div>
</div>
<?php endif; ?>
