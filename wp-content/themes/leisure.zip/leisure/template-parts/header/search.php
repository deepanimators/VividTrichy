<form id="search-form" action="<?php echo esc_url( home_url( '/' ) ); ?>"  class="hidden-xs">
		<div class="container-fluid">
			<div class="row">
				<div class="col-lg-12 text-center">
					<input type="text" class="search-field" name="s" placeholder="<?php _e( "Type something to search  ...", "leisure" ) ?>">
					<a href="#" class="close-search fa fa-search"></a>	
				</div>
			</div>
		</div>
</form><!-- #search-form -->