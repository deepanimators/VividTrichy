<?php do_action( 'xtender_sharing' ); ?>
